<template>
  <h1>Error 404: {{ $route.params.catchAll }} not found.</h1>
  Back to <router-link to="/">home</router-link>
</template>
